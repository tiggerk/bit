package beautyChu.dao;

import java.util.List;
import beautyChu.domain.Maker;

public interface MakerDao {
 
}
