package beautyChu.dao;

import java.util.Map;
import beautyChu.domain.Member;

public interface MemberDao {

}
